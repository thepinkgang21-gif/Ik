Swing Tag, iOS wrapper

1. Create a free GitHub account and a new PUBLIC repository (public repos get free macOS build time).
2. Upload everything in this folder to the repo, including the hidden .github folder.
3. Open the Actions tab, pick "Build IPA", press Run workflow, and wait a few minutes.
4. Open the finished run, download the SwingTag-ipa artifact, unzip it to get SwingTag.ipa.
5. Open SwingTag.ipa in KSign and sign it as usual.

The game needs an internet connection to load its 3D library and font.
Credits for the map and gorilla models are in the game's Credits menu.
